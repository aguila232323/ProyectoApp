package Modelo;

public class Ingrediente {

    private final int id;
    private final String NombreIngrediente;
    private final String Alergenos;
    private final int Calorias;
    private final String TipoIngrediente;

    public Ingrediente(int Id, String NombreIngrediente, String Alergenos, int Calorias, String TipoIngrediente){
        this.id = Id;
    	this.NombreIngrediente=NombreIngrediente;
        this.Alergenos = Alergenos;
        this.Calorias=Calorias;
        this.TipoIngrediente=TipoIngrediente;
    }
    

    public int getId() {
    	return id;
    }
    public String getNombreIngrediente() {
        return NombreIngrediente;
    }

    public String getAlergenos() {
        return Alergenos;
    }

    public int getCalorias() {
        return Calorias;
    }

    public String getTipoIngrediente() {
        return TipoIngrediente;
    }
}
