package VentanaAnadirRegistro;
import AppPrincipal.Ejercicio2Builder;
import VentanaVerIngrediente.*;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.controlsfx.validation.Severity;
import org.controlsfx.validation.ValidationMessage;
import org.controlsfx.validation.ValidationResult;
import org.controlsfx.validation.ValidationSupport;
import org.controlsfx.validation.Validator;
import org.controlsfx.validation.decoration.GraphicValidationDecoration;

public class anadirDatosRecetasBuilder implements Initializable {
    
    Image foto;
    
    public boolean editar = false;

    private Ejercicio2Builder controladorBuilder;
    
    
    List<ValidationSupport> validadores;

    @FXML
    private Button aceptar;

    @FXML
    private Button botonSeleccionarImagen;

    @FXML
    private Button cancelar;

    @FXML
    private ImageView imagenSeleccionarFichero;
    
    @FXML
    private Label LabelDificultad;

    @FXML
    private Label LabelNombre;

    @FXML
    private Label LabelPasos;

    @FXML
    private Label LabelTiempo;

    @FXML
    private Label iconoNombreLabel;
 
    
    @FXML
    private TextField CampoNombre;

    @FXML
    private TextField CampoTiempo;

    @FXML
    private ComboBox<String> ComboDificultad;

    @FXML
    private TextField campoImagen;

    @FXML
    private TextField campoPasos;

    @FXML
    void aceptar(ActionEvent event) {
       
        System.out.println("Comprobación de DATOS");
        System.out.println("=====================");
        for (ValidationSupport validationSupport : validadores) {
            ValidationResult resultados = validationSupport.getValidationResult();
            System.out.println("Validador: " + validationSupport.getRegisteredControls());
            System.out.println("Errores: " + resultados.getErrors());
            System.out.println("Infos: " + resultados.getInfos());
            System.out.println("Mensajes: " + resultados.getMessages());
            System.out.println("Warnings: " + resultados.getWarnings());
        }

        boolean todoOK = true;
        for (ValidationSupport validationSupport : validadores) {
            todoOK = (todoOK && validationSupport.getValidationResult().getErrors().isEmpty());
        }

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        if (todoOK) {
            alert.setContentText("TODO CORRECTO!!!");
            if (editar) {
                System.err.println();
                if (campoImagen.getText().equals("")) {
                    
                     controladorBuilder.modificarReceta(controladorBuilder.RecetaSeleccionada().getId(),
                             CampoNombre.getText(),Integer.parseInt(CampoTiempo.getText()),
                             campoPasos.getText(),
                             ComboDificultad.getValue(),
                             controladorBuilder.RecetaSeleccionada().getFoto());
                     System.err.println("imagen sin convertida");
                }else{
                    
                     controladorBuilder.modificarReceta(controladorBuilder.RecetaSeleccionada().getId(),
                             CampoNombre.getText(),
                             Integer.parseInt(CampoTiempo.getText()),
                             campoPasos.getText(),
                             ComboDificultad.getValue(),
                             controladorBuilder.convetir64(foto));
                     System.err.println("imagen convertida");
                     
                }
               
            }else{
                controladorBuilder.insertarReceta(CampoNombre.getText(), Integer.parseInt(CampoTiempo.getText()), campoPasos.getText(), ComboDificultad.getValue(), controladorBuilder.convetir64(foto));
            }
            
            Stage stage = (Stage) aceptar.getScene().getWindow();
            stage.close();
        } else {
            alert.setContentText("El formulario sigue teniendo ERRORES!!!");
        }
        alert.showAndWait();
        
       
    }

    @FXML
    void cancelar(ActionEvent event) {
        Stage stage = (Stage) cancelar.getScene().getWindow();
        stage.close();

    }

    @FXML
    void seleccionarImagen(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setInitialDirectory(new File("src"));
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Imagen jpg", "*.jpg"),
                new FileChooser.ExtensionFilter("Imagen png", "*.png")
        );
        
        
        File archivoSeleccionado = fileChooser.showOpenDialog(null);
            if (archivoSeleccionado != null) {
                System.out.println("NO URI:"+archivoSeleccionado.toString());
                
                String rutaArchivo = archivoSeleccionado.toURI().toString();
                System.out.println("URI:"+rutaArchivo);
                Image imagen = new Image(rutaArchivo);
                campoImagen.setText(rutaArchivo);
                
                
                foto = imagen;
                
            }

    }
   
    public void setControladorEnlace(Ejercicio2Builder ejercicio2Builder) {
        controladorBuilder = ejercicio2Builder;
        if (editar) {
            editar();
        }  
    }
    
    public void editar() {
        CampoNombre.setText(controladorBuilder.RecetaSeleccionada().getNombreReceta());
        campoPasos.setText(controladorBuilder.RecetaSeleccionada().getPasos());
        ComboDificultad.setValue(controladorBuilder.RecetaSeleccionada().getDificultad());
        CampoTiempo.setText(""+controladorBuilder.RecetaSeleccionada().getTiempo());
        
    }
    

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
        imagenSeleccionarFichero.setImage(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/lupa.png")));
     
        validadores = new ArrayList<>();
        
        ObservableList<String> dificultad = FXCollections.observableArrayList("Fácil","Intermedia","Difícil");
        ComboDificultad.getItems().addAll(dificultad);
        ComboDificultad.setValue("Fácil");

        
        
        LabelNombre.setTooltip(new Tooltip("Nombre de la Receta"));
        LabelTiempo.setTooltip(new Tooltip("Número (máximo 3 dígitos) expresado en minutos"));
        LabelPasos.setTooltip(new Tooltip("Pasos de la receta"));
        LabelDificultad.setTooltip(new Tooltip("Selecciona una dificultad"));
        
        
        ImageView iconoOk = new ImageView(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/ok_icon.png")));
        ImageView iconoErr = new ImageView(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/error_icon.png")));
        iconoOk.setFitHeight(16);
        iconoOk.setFitWidth(16);
        iconoErr.setFitHeight(16);
        iconoErr.setFitWidth(16);
        
       
        
        ValidationSupport vSnombre = new ValidationSupport();
        
        
        vSnombre.registerValidator(CampoNombre,false,  (Control c, String texto) -> {
            if (texto.length() == 0) {
                return ValidationResult.fromWarning(c, "Val 3: El nombre no debe estar vacío");
            } else if (texto.length() < 5 || texto.length() > 100) {
                return ValidationResult.fromError(c, "Val 3: El nombre debe tener entre 5 y 100 caracteres");
            } else {
                return ValidationResult.fromInfo(c, "Val 3: OK");
            }
        });
        
        
        ValidationSupport vSTiempo = new ValidationSupport();
        Validator<String> rangoValidator = Validator.createPredicateValidator(valor -> {
            if (valor == null || valor.isEmpty()) {
                return false;
            }
            try {
                int number = Integer.parseInt(valor);
                return number >= 0 && number <= 999;
            } catch (NumberFormatException e) {
                return false; 
            }
        }, "Valor debe estar entre 0 y 999 o NO es un número");
        vSTiempo.registerValidator(CampoTiempo, false, rangoValidator);
        
        
        ValidationSupport vSdificultad = new ValidationSupport();
        Validator<String> validadorCombo = Validator.createPredicateValidator(
                texto -> !("".equals(texto)),
                "Hay que elegir dificultad!", 
                Severity.ERROR 
        );
        vSdificultad.registerValidator(ComboDificultad,false, validadorCombo);
        
        
        GraphicValidationDecoration decorador = new GraphicValidationDecoration() {
            @Override
            public void applyValidationDecoration(ValidationMessage message) {
                super.applyValidationDecoration(message);
                System.out.println("Mensaje:" + message);
                
                if (message.getSeverity() == Severity.ERROR || message.getSeverity() == Severity.WARNING) {
                    iconoNombreLabel.setGraphic(iconoErr);//ICONO ERROR
                } else if (message.getSeverity() == Severity.INFO) {
                   iconoNombreLabel.setGraphic(iconoOk);//ICONO OK
                }
            }
        };
        
        
        
        validadores = new ArrayList<>();
        validadores.addAll(Arrays.asList(vSnombre, vSTiempo, vSdificultad));
        
        
        Platform.runLater(() -> {
            for (ValidationSupport validationSupport : validadores) {
                validationSupport.initInitialDecoration();
            }
            vSnombre.setValidationDecorator(decorador);
        });
        
    }

}



