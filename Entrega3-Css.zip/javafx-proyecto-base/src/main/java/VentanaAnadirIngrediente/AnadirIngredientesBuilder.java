package VentanaAnadirIngrediente;
import AppPrincipal.Ejercicio2Builder;
import Modelo.Ingrediente;
import Modelo.Receta;
import java.net.URL;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;



public class AnadirIngredientesBuilder implements Initializable {

    ObservableList<String> listaTotalIngredientes = FXCollections.observableArrayList();
    ObservableList<String> listaEspecificaIngredientes = FXCollections.observableArrayList();

    private Ejercicio2Builder controladorBuilder;
    
    @FXML
    private ListView<String> ListViewIngredientes;

    @FXML
    private ListView<String> ListViewTotalIngredientes;

    @FXML
    private Text NombreReceta;
    
     @FXML
    private TextField campoBuscador;


    @FXML
    private Button botonAceptar;

    @FXML
    private Button botonAñadir;

    @FXML
    private Button botonCancelar;

    @FXML
    private Button botonEliminar;
    
    @FXML
    private Button btnEditar;
    
    @FXML
    private ImageView imagenBuscador;
    
    @FXML
    private ImageView imagenAñadirFlecha;

    @FXML
    private ImageView imagenEliminarFlecha;


    @FXML
    void Añadir(ActionEvent event) {
        
        String seleccionado = ListViewTotalIngredientes.getSelectionModel().getSelectedItem();
        
        if (seleccionado != null) {
            mostrarVentanaCantidad(false);
            ListViewTotalIngredientes.getItems().remove(seleccionado);
            ListViewIngredientes.getItems().add(seleccionado);
        }
        
    }
    @FXML
    void editarCantidad(ActionEvent event) {
        
        if (!(ListViewIngredientes.getSelectionModel().getSelectedItem()==null)) {
            
            mostrarVentanaCantidad(true);
            
        }

    }
    
    

    @FXML
    void aceptar(ActionEvent event) {
        Stage stage = (Stage) botonAceptar.getScene().getWindow();
        stage.close();
    }

    @FXML
    void cancelar(ActionEvent event) {
        Stage stage = (Stage) botonCancelar.getScene().getWindow();
        stage.close();
    }

    @FXML
    void eliminar(ActionEvent event) {
        
     
        String seleccionado = ListViewIngredientes.getSelectionModel().getSelectedItem();

        if (seleccionado != null) {
           
            int idIngrediente = encontrarId(seleccionado);

            if (idIngrediente != -1) {
                controladorBuilder.borrarIngredienteContiene(idIngrediente, controladorBuilder.RecetaSeleccionada().getId());
                ListViewIngredientes.getItems().remove(seleccionado);
                ListViewTotalIngredientes.getItems().add(seleccionado);
            } else {
                
                Alert alerta = new Alert(Alert.AlertType.ERROR);
                alerta.setTitle("Error");
                alerta.setHeaderText("Ingrediente no encontrado");
                alerta.setContentText("El ingrediente seleccionado no se pudo eliminar.");
                alerta.showAndWait();
            }
    }


        

    }
    
    
    @FXML
    void buscar(ActionEvent event) {
        if (campoBuscador.getText() == null) {
            Alert alertaSalir = new Alert(Alert.AlertType.ERROR);
            alertaSalir.setHeaderText("Error No has Introducido Ningun dato para buscar");
            alertaSalir.setTitle("Error Busqueda");
            alertaSalir.showAndWait();
         }else{
                 String ingrediente = null;
                 
                  for (String ingrediente2 : listaTotalIngredientes) {
                      if (ingrediente2.toLowerCase().equals(campoBuscador.getText().toLowerCase())) {
                          ingrediente = ingrediente2;
                          break;
                      }
                 }
                 
                  if (ingrediente == null) {
                    Alert alertaSalir = new Alert(Alert.AlertType.ERROR);
                    alertaSalir.setHeaderText("Error ingrediente introducido no existe");
                    alertaSalir.setTitle("Error Busqueda");
                    alertaSalir.showAndWait();
                     
                 }else{
                      ListViewTotalIngredientes.getSelectionModel().select(ingrediente);
                      
                 }  
        }

    }
    
    private void ordenarListaIngredientes(){
        Set<String> ingredientesSeleccionadosSet = new HashSet<>(controladorBuilder.ListaIngredientesSeleccionada(true));

   
        for (Ingrediente ingredienteListaTotal : controladorBuilder.dameListaIngredientes()) {
            String nombreIngrediente = ingredienteListaTotal.getNombreIngrediente();
            if (ingredientesSeleccionadosSet.contains(nombreIngrediente)) {
                listaEspecificaIngredientes.add(nombreIngrediente);
            } else {
                listaTotalIngredientes.add(nombreIngrediente);
            }
        }
        ListViewTotalIngredientes.setItems(listaTotalIngredientes);
        ListViewIngredientes.setItems(listaEspecificaIngredientes);
    }
    
    private int encontrarId(String NombreIngredienteABuscar){
        int indice = -1; 
        
        for (Ingrediente ingrediente : controladorBuilder.dameListaIngredientes()) {
            if (ingrediente.getNombreIngrediente().equals(NombreIngredienteABuscar)) {
                indice = ingrediente.getId();
            }
        }
        return indice;
    }
    
    private void mostrarVentanaCantidad(boolean editar) {
        
        Stage ventana = new Stage();
        ventana.initModality(Modality.APPLICATION_MODAL);
        ventana.setTitle("Ingresar Cantidad y Unidad");
        Label labelCantidad = new Label("Cantidad:");
        TextField textCantidad = new TextField();
        Label labelUnidad = new Label("Unidad de medida:");
        ComboBox<String> comboUnidad = new ComboBox<>();
        comboUnidad.getItems().addAll("gramos", "mililitros");
        Button btnAceptar = new Button("Aceptar");
        Button btnCancelar = new Button("Cancelar");

       
        btnAceptar.setOnAction(event -> {
            String cantidad = textCantidad.getText();
            String unidad = comboUnidad.getValue();
            
    

            if (cantidad.isEmpty() || unidad == null) {
                Alert alertaSalir = new Alert(Alert.AlertType.WARNING);
                alertaSalir.setHeaderText("Por favor, completa todos los campos");
                alertaSalir.setTitle("Salir");
                alertaSalir.showAndWait();
                 
            } else {
                if (editar) {
                    System.out.println("ECantidad: " + cantidad + ", EUnidad: " + unidad);
                    controladorBuilder.actualizarIngredienteContiene(encontrarId(ListViewIngredientes.getSelectionModel().getSelectedItem()),
                    controladorBuilder.RecetaSeleccionada().getId(),
                    Integer.parseInt(cantidad),
                    unidad);
                    ventana.close();
                    
                }else{
                    System.out.println("Cantidad: " + cantidad + ", Unidad: " + unidad);
                    controladorBuilder.agregarIngredienteContiene(encontrarId(ListViewTotalIngredientes.getSelectionModel().getSelectedItem()),
                    controladorBuilder.RecetaSeleccionada().getId(),
                    Integer.parseInt(cantidad),
                    unidad);
                    ventana.close();
                }
                
            }
        });
        btnCancelar.setOnAction(event -> ventana.close());

        
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(10));
        layout.getChildren().addAll(labelCantidad, textCantidad, labelUnidad, comboUnidad, btnAceptar, btnCancelar);
        Scene scene = new Scene(layout, 250, 200);
        ventana.setScene(scene);
        ventana.showAndWait();
    
    }
    public void setControladorEnlace(Ejercicio2Builder ejercicio2Builder) {
        controladorBuilder = ejercicio2Builder;
        NombreReceta.setText(ejercicio2Builder.RecetaSeleccionada().getNombreReceta());
        ordenarListaIngredientes();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        imagenAñadirFlecha.setImage(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/flechaAñadir.png")));
        imagenEliminarFlecha.setImage(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/flechaBorrar.png")));
        imagenBuscador.setImage(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/lupa.png")));
    }

}



