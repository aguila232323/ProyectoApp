package AppPrincipal;
import Modelo.Ingrediente;
import Modelo.Receta;
import VentanaAnadirIngrediente.AnadirIngredientesBuilder;
import VentanaAnadirRegistro.anadirDatosIngredientesBuilder;
import VentanaAnadirRegistro.anadirDatosRecetasBuilder;
import VentanaVerIngrediente.VerIngredientesBuilder;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import javafx.animation.FadeTransition;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import static java.lang.System.exit;
import java.net.URL;
import java.rmi.server.RMIClassLoader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Base64;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.fxml.Initializable;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.util.Duration;
import javax.imageio.ImageIO;



public class Ejercicio2Builder implements Initializable {
    
    Connection conexion;
    Statement st;
    ResultSet rs;
    

    
    private VerIngredientesBuilder controladorVerIngredientes;
    private AnadirIngredientesBuilder controladorAnadirIngredientesBuilder;
    private anadirDatosIngredientesBuilder controladorDatosIngredientesBuilder;
    private anadirDatosRecetasBuilder controladorDatosRecetasBuilder;
    
    ObservableList<Receta> listaReceta = FXCollections.observableArrayList();
    
    ObservableList<Image> listaImgAlergenos = FXCollections.observableArrayList(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/Gluten.png")),
                new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/Crustaceos.png")),
                new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/Huevos.png")),
                new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/Pescado.png")),
                new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/Cacahuetes.png")),
                new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/Soja.png")),
                new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/Leche.png")),
                new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/FrutosSecos.png")),
                new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/Apio.png")),
                new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/Mostaza.png")),
                new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/Sesamo.png")),
                new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/Sulfitos.png")),
                new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/Altramuces.png")),
                new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/Moluscos.png")),
                new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/Nada.png"))
                    
        );
    
    public ObservableList<String> alergenosObservableList = FXCollections.observableArrayList(
                "Gluten",
                "Crustáceos",
                "Huevos",
                "Pescado",
                "Cacahuetes",
                "Soja",
                "Leche y productos lácteos",
                "Frutos secos",
                "Apio",
                "Mostaza",
                "Sésamo",
                "Sulfitos",
                "Altramuz",
                "Moluscos",
                "Ninguno"
        );
    
    
    ObservableList<Ingrediente> listaIngrediente = FXCollections.observableArrayList();

    @FXML
    private TableView<Receta> DatosRecetas;
    
    @FXML
    private TableView<Ingrediente> DatosIngredientes;

    @FXML
    private TableColumn<Receta,String> Dificultad;

    @FXML
    private TableColumn<Receta, Integer> Id_Recetas;
    
    @FXML
    private TableColumn<Receta, String> Nombre_Recetas;

    @FXML
    private TableColumn<Receta, String> Pasos;
    
    @FXML
    private TableColumn<Receta, Integer> Tiempo;

    @FXML
    private TableColumn<Receta,String> Imagen;
    
    @FXML
    private TableColumn<Ingrediente, Integer> Id_Ingrediente;
    
    @FXML
    private TableColumn<Ingrediente, String> TipoIngrediente;
    
    @FXML
    private TableColumn<Ingrediente, String> NombreIngrediente;
    
    @FXML
    private TableColumn<Ingrediente, String> Alergenos;

    @FXML
    private TableColumn<Ingrediente, Integer> Calorias;
    
    @FXML
    private TextField campoID_Ingrediente;

    @FXML
    private TextField campoIdRecetas;
    
    
    @FXML
    private TextField campoNombreReceta;

    @FXML
    private TextField campoNombreIngrediente;

    @FXML
    private TextArea campoPasos;

    @FXML
    private TextField campoTiempo;

    @FXML
    private TextField campoTipoIngredientes;
    
    @FXML
    private ImageView imgAlergenos;

    @FXML
    private TextField campoCalorias;

    @FXML
    private TextField campoDificultad;

    @FXML
    private ImageView ImagenReceta;
    
    @FXML
    private ImageView imagenBuscar;

    @FXML
    private Tab Recetas;

    @FXML
    private TabPane Tablas;

    @FXML
    private AnchorPane TeXT;
    
    @FXML
    private TextField campoBusqueda;


    @FXML
    private Button VerIngrediente;

    @FXML
    private Button ayuda;

    @FXML
    private Button añadir;

    @FXML
    private Button añadirIngrediente;

    @FXML
    private Button borrar;

    @FXML
    private Button editar;

    @FXML
    private Pane panePrincipal;

    @FXML
    private Button salir;
    
    @FXML
    private Button btnBuscar;
    
     @FXML
    private ImageView imagenAñadir;

    @FXML
    private ImageView imagenBorrar;
    

    @FXML
    private ImageView imagenEditar;

    @FXML
    private ImageView imagenSalir;
    
    @FXML
    private ImageView imagenAñadirIngredientes;
    
    @FXML
    private ImageView imagenVerIngredientes;
    
    @FXML
    private ImageView imagenAyuda;

    @FXML
    private ToolBar toolbar;

    @FXML
    private ToolBar toolbar2;

    @FXML
    private ToolBar toolbar3;

    @FXML
    void VerIngrediente(ActionEvent event) {
        if (Tablas.getSelectionModel().getSelectedItem().equals(Recetas) && DatosRecetas.getSelectionModel().getSelectedItem() != null){
            try {
                
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/VentanaVerIngrediente/VerIngredientes.fxml"));
                Parent root = loader.load();
                controladorVerIngredientes = loader.getController();
                controladorVerIngredientes.setControladorEnlace(this);
                
                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.setResizable(false);
                stage.setScene(scene);
                stage.setTitle("Ver Ingrediente");
                stage.getIcons().add(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/VerIngredientes.png")));
                stage.show();
                
                
            } catch (Exception e) {
                
                e.printStackTrace();

            }
        }else{
            if (Tablas.getSelectionModel().getSelectedItem().equals(Recetas)) {
                mostrarError("Error Seleccion", "No has seleccionado ninguna receta");
            }else{
                mostrarError("Error Panel", "No puedes usar esta Funcion sin estar en Recetas ");
            }
           
        }
    }
    
    @FXML
    void añadirIngrediente(ActionEvent event) {
        
        if (Tablas.getSelectionModel().getSelectedItem().equals(Recetas) && DatosRecetas.getSelectionModel().getSelectedItem() != null){
           
            Stage escenario2 = new Stage();

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/VentanaAnadirIngrediente/AñadirIngredientes2.fxml"));
                Parent root = loader.load();
                
                controladorAnadirIngredientesBuilder = loader.getController();
                controladorAnadirIngredientesBuilder.setControladorEnlace(this);
                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.setResizable(false);
                stage.setScene(scene);
                stage.setTitle("Añadir Ingrediente");
                stage.getIcons().add(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/AñadirIngredientes.png")));
                stage.show();
            } catch (Exception e) {
                System.out.println(e);
            }
            
            
        }else{
            if (Tablas.getSelectionModel().getSelectedItem().equals(Recetas)) {
                mostrarError("Error Seleccion", "No has seleccionado ninguna receta");
            }else{
                mostrarError("Error Panel", "No puedes usar esta Funcion sin estar en Recetas ");
            }
            
            
        }
    }
    
    
    
    @FXML
    void añadirCampos(ActionEvent event) {
 
        if (Tablas.getSelectionModel().getSelectedItem().equals(Recetas)){
            try {
                
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/VentanaAnadirRegistro/anadirDatosRecetas.fxml"));
                Parent root = loader.load();
                controladorDatosRecetasBuilder = loader.getController();
                controladorDatosRecetasBuilder.setControladorEnlace(this);
                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.setResizable(false);
                stage.setScene(scene);
                stage.setTitle("Añadir Recetas");
                stage.getIcons().add(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/añadir.png")));
                stage.show();
                
                
            } catch (Exception e) {
                
                e.printStackTrace();

            }
        }else{
            try {
                
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/VentanaAnadirRegistro/anadirDatosIngredientes.fxml"));
                Parent root = loader.load();
                controladorDatosIngredientesBuilder = loader.getController();
                controladorDatosIngredientesBuilder.setControladorEnlace(this);
                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.setResizable(false);
                stage.setScene(scene);
                stage.setTitle("Añadir Ingrediente");
                stage.getIcons().add(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/añadir.png")));
                stage.show();
                
                
            } catch (Exception e) {
                
                e.printStackTrace();

            }
           
        }
        
        
        
    }

    @FXML
    void borrarCampo(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmar eliminación");
        
        Stage alerStage = (Stage)alert.getDialogPane().getScene().getWindow();
        alerStage.getIcons().add(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/eliminar.png")));
        
        
     
        String nombre = "";
        if (Tablas.getSelectionModel().getSelectedItem().equals(Recetas)) {
           nombre+=DatosRecetas.getSelectionModel().getSelectedItem().getNombreReceta()+"?";
        }else{
            nombre+=DatosIngredientes.getSelectionModel().getSelectedItem().getNombreIngrediente()+"?";
        }
        alert.setHeaderText("¿Estás seguro de que deseas eliminar este registro: "+nombre);
        
        

        String query = "DELETE FROM Receta WHERE Id_Receta=?";
        String id = campoIdRecetas.getText();
        
        if (alert.showAndWait().get() == ButtonType.OK) {
            
            if (!Tablas.getSelectionModel().getSelectedItem().equals(Recetas)) {
                query = "DELETE FROM Ingredientes WHERE Id_Ingrediente=?";
                id = campoID_Ingrediente.getText();
            }
            
            try {
                PreparedStatement preparedStatement = this.conexion.prepareStatement(query);
                preparedStatement.setInt(1, Integer.parseInt(id));
                preparedStatement.executeUpdate();
                System.out.println("Borrado correctamente");
           } catch (SQLException e) {
               System.out.println("Excepción: " + e.getMessage());
           }
            
            
            if (Tablas.getSelectionModel().getSelectedItem().equals(Recetas)) {
                mostrarReceta();
                borrarCampos(true);
            } else {
               mostrarIngredientes();
                borrarCampos(false);
            }
            
               
        } else {
            System.out.println("Eliminación cancelada.");
        }      
    }

    @FXML
    void editarCampo(ActionEvent event) {
        if (Tablas.getSelectionModel().getSelectedItem().equals(Recetas) && DatosRecetas.getSelectionModel().getSelectedItem() != null){
            try {
                
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/VentanaAnadirRegistro/anadirDatosRecetas.fxml"));
                Parent root = loader.load();
                controladorDatosRecetasBuilder = loader.getController();
                controladorDatosRecetasBuilder.editar=true;
                controladorDatosRecetasBuilder.setControladorEnlace(this);
                
                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.setResizable(false);
                stage.setScene(scene);
                stage.getIcons().add(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/editar.png")));
                stage.setTitle("Editar Recetas");
                stage.show();
                
                
            } catch (Exception e) {
                
                e.printStackTrace();

            }
        }else if (DatosIngredientes.getSelectionModel().getSelectedItem() != null) {
            try {
                
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/VentanaAnadirRegistro/anadirDatosIngredientes.fxml"));
                Parent root = loader.load();
                controladorDatosIngredientesBuilder = loader.getController();
                controladorDatosIngredientesBuilder.editar=true;
                controladorDatosIngredientesBuilder.setControladorEnlace(this);
                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.setResizable(false);
                stage.setScene(scene);
                stage.getIcons().add(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/editar.png")));
                stage.setTitle("Editar Ingrediente");
                stage.show();
                
                
            } catch (Exception e) {
                
                e.printStackTrace();

            }
           
        }

    }

    @FXML
    void salir(ActionEvent event) {
        Alert alertaSalir = new Alert(Alert.AlertType.WARNING);
        
        Stage alerStage = (Stage)alertaSalir.getDialogPane().getScene().getWindow();
        alerStage.getIcons().add(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/salida.png")));
        alertaSalir.setHeaderText("¿Esta seguro que quiere salir?");
        alertaSalir.setTitle("Salir");
        alertaSalir.showAndWait();
        Platform.exit();

    }
    
     @FXML
    void ayuda(ActionEvent event) {
        
        Stage ventanaAyuda = new Stage();
        ventanaAyuda.initModality(Modality.APPLICATION_MODAL);
        ventanaAyuda.setTitle("Instrucciones de Ayuda");
        ventanaAyuda.getIcons().add(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/ayuda.png")));
        ventanaAyuda.getIcons().add(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/ayuda.png")));

        VBox layoutAyuda = new VBox(10);
        layoutAyuda.setStyle("-fx-padding: 10; -fx-alignment: center;");
        
        HBox fila1 = new HBox(5);
        ImageView icono1 = new ImageView(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/AñadirIngredientes.png")));
        icono1.setFitHeight(20);
        icono1.setFitWidth(20);
        javafx.scene.control.Label etiqueta1 = new javafx.scene.control.Label("Añadir Ingrediente: Permite modificar los ingredientes a una receta.");
        fila1.getChildren().addAll(icono1, etiqueta1);

        HBox fila2 = new HBox(5);
        ImageView icono2 = new ImageView(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/verIngredientes.png")));
        icono2.setFitHeight(20);
        icono2.setFitWidth(20);
        javafx.scene.control.Label etiqueta2 = new javafx.scene.control.Label("Ver Ingredientes: Nos muestra todos los ingredientes que contiene una receta.");
        fila2.getChildren().addAll(icono2, etiqueta2);

        HBox fila3 = new HBox(5);
        ImageView icono3 = new ImageView(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/añadir.png")));
        icono3.setFitHeight(20);
        icono3.setFitWidth(20);
        javafx.scene.control.Label etiqueta3 = new javafx.scene.control.Label("Añadir: Añade un nuevo elemento a la tabla.");
        fila3.getChildren().addAll(icono3, etiqueta3);

        HBox fila4 = new HBox(5);
        ImageView icono4 = new ImageView(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/eliminar.png")));
        icono4.setFitHeight(20);
        icono4.setFitWidth(20);
        javafx.scene.control.Label etiqueta4 = new javafx.scene.control.Label("Borrar: Borra un elemento de la tabla.");
        fila4.getChildren().addAll(icono4, etiqueta4);

        HBox fila5 = new HBox(5);
        ImageView icono5 = new ImageView(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/editar.png")));
        icono5.setFitHeight(20);
        icono5.setFitWidth(20);
        javafx.scene.control.Label etiqueta5 = new javafx.scene.control.Label("Editar: Permite editar cada uno de los campos de un elemento.");
        fila5.getChildren().addAll(icono5, etiqueta5);

        
        layoutAyuda.getChildren().addAll(fila1, fila2, fila3, fila4, fila5);

        Button btnCerrar = new Button("Cerrar");
        btnCerrar.setOnAction(e -> ventanaAyuda.close());
        layoutAyuda.getChildren().add(btnCerrar);

        Scene sceneAyuda = new Scene(layoutAyuda, 500, 200);
        ventanaAyuda.setScene(sceneAyuda);
        ventanaAyuda.showAndWait();
    
    }
    
     @FXML
            
    void buscar(ActionEvent event) {

         if (campoBusqueda.getText() == null) {
            Alert alertaSalir = new Alert(Alert.AlertType.ERROR);
            alertaSalir.setHeaderText("Error No has Introducido Ningun dato para buscar");
            alertaSalir.setTitle("Error Busqueda");
            alertaSalir.showAndWait();
         }else{
             if (Tablas.getSelectionModel().getSelectedItem().equals(Recetas)) {
                 
                 Receta receta = null;
                 
                  for (Receta receta1 : listaReceta) {
                      if (receta1.getNombreReceta().toLowerCase().equals(campoBusqueda.getText().toLowerCase())) {
                          receta = receta1;
                          break;
                      }
                 }
                 
                  if (receta == null) {
                    Alert alertaSalir = new Alert(Alert.AlertType.ERROR);
                    alertaSalir.setHeaderText("Error la receta introducida no existe");
                    alertaSalir.setTitle("Error Busqueda");
                    alertaSalir.showAndWait();
                     
                 }else{
                      DatosRecetas.getSelectionModel().select(receta);
                      actualizarCampos(true);
                 }
                 
             }else{
                 Ingrediente ingrediente = null;
                 
                  for (Ingrediente ingrediente1 : listaIngrediente) {
                      if (ingrediente1.getNombreIngrediente().toLowerCase().equals(campoBusqueda.getText().toLowerCase())) {
                          ingrediente = ingrediente1;
                          break;
                      }
                 }
                 
                  if (ingrediente == null) {
                    Alert alertaSalir = new Alert(Alert.AlertType.ERROR);
                    alertaSalir.setHeaderText("Error el ingrediente introducida no existe");
                    alertaSalir.setTitle("Error Busqueda");
                    alertaSalir.showAndWait();
                     
                 }else{
                      DatosIngredientes.getSelectionModel().select(ingrediente);
                      actualizarCampos(false);
                 }
                 
             }
         }
        
        
    }
    
    
 
    
    
    @FXML void datosRecetas(MouseEvent event) {
        actualizarCampos(true);
       
    }
    @FXML void datosIngredientes(MouseEvent event) {
        actualizarCampos(false);
    }
    
    
    
    
    
    
    public Connection getConnection() throws IOException {
        Properties properties = new Properties();
        String IP, PORT, BBDD, USER, PWD;
        
        try {
            InputStream input_ip = new FileInputStream("ip.properties");
            properties.load(input_ip);
            IP = (String) properties.get("IP");
        } catch (FileNotFoundException e) {
            System.out.println("No se pudo encontrar el archivo de propiedades para IP, se establece localhost por defecto");
            IP = "localhost";
        }

        InputStream input = new FileInputStream("bbdd.properties");
        if (input == null) {
            System.out.println("No se pudo encontrar el archivo de propiedades");
            return null;
        } else {
            properties.load(input);
            PORT = (String) properties.get("PORT");
            BBDD = (String) properties.get("BBDD");
            USER = (String) properties.get("USER"); 
            PWD = (String) properties.get("PWD");

            Connection conn;
            try {
                
                conn = DriverManager.getConnection("jdbc:mysql://" + IP + ":" + PORT + "/" + BBDD, USER, PWD);
                return conn;
            } catch (SQLException e) {
                System.out.println("Error SQL: " + e.getMessage());
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Ha ocurrido un error de conexión");
                alert.setContentText(e.getMessage());
                alert.showAndWait();
                exit(0);
                return null;
            }
        }
    }
     public ObservableList<Receta> dameListaRecetas() {
        if (conexion != null) {
            listaReceta.clear();
            String query = "SELECT * FROM Receta";
            try {
                rs = st.executeQuery(query);
                Receta receta;
                while (rs.next()) { 
                    receta = new Receta(rs.getInt("Id_Receta"), rs.getString("NombreReceta"), rs.getString("PasosPreparacion"),rs.getInt("TiempoPreparacion"),rs.getString("Dificultad"),rs.getString("Foto"));
                    listaReceta.add(receta);
                }
            } catch (SQLException e) {
                System.out.println("Excepción SQL: "+e.getMessage());
            }
            return listaReceta;
        }
        return null;
    }
     
     
     
    public ObservableList<Ingrediente> dameListaIngredientes() {
        if (conexion != null) {
            listaIngrediente.clear();
            String query = "SELECT * FROM Ingredientes";
            try {
                rs = st.executeQuery(query);
                Ingrediente ingrediente;
                while (rs.next()) {
                    ingrediente  = new Ingrediente(rs.getInt("Id_Ingrediente"), rs.getString("NombreIngrediente"), rs.getString("Alergenos"),rs.getInt("Calorias"),rs.getString("TipoIngrediente"));
                    listaIngrediente.add(ingrediente);
                }
            } catch (SQLException e) {
                System.out.println("Excepción SQL: "+e.getMessage());
            }
            return listaIngrediente;
        }
        return null;
    }
    

    
    public void mostrarReceta() {
        DatosRecetas.setItems(dameListaRecetas());
    }
    
    public void mostrarIngredientes() {
        DatosIngredientes.setItems(dameListaIngredientes());
    }
    
     private void mostrarError(String titulo, String mensaje) {
        
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje); 
        alerta.showAndWait();
    }
    
    private void borrarCampos(boolean EsReceta){
        
        if (EsReceta) {
            campoIdRecetas.setText("");
            campoNombreReceta.setText("");
            campoPasos.setText("");
            campoTiempo.setText("");
            campoDificultad.setText("");
            ImagenReceta.setImage(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/Vacio.png")));
        }else{
            campoID_Ingrediente.setText("");
            campoNombreIngrediente.setText("");
            campoCalorias.setText("");
            campoTipoIngredientes.setText("");
            imgAlergenos.setImage(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/Vacio.png")));
        }
        
    }
    
    
    private void actualizarCampos(boolean EsReceta){
        
        if (EsReceta) {
            campoIdRecetas.setText(""+DatosRecetas.getSelectionModel().getSelectedItem().getId());
            campoNombreReceta.setText(DatosRecetas.getSelectionModel().getSelectedItem().getNombreReceta());
            campoPasos.setText(DatosRecetas.getSelectionModel().getSelectedItem().getPasos());
            campoTiempo.setText(""+DatosRecetas.getSelectionModel().getSelectedItem().getTiempo());
            campoDificultad.setText(DatosRecetas.getSelectionModel().getSelectedItem().getDificultad());
            ImagenReceta.setImage(convertirDesdeBase64(DatosRecetas.getSelectionModel().getSelectedItem().getFoto()));
        }else{
            campoID_Ingrediente.setText(""+DatosIngredientes.getSelectionModel().getSelectedItem().getId());
            campoNombreIngrediente.setText(DatosIngredientes.getSelectionModel().getSelectedItem().getNombreIngrediente());
            campoCalorias.setText(""+DatosIngredientes.getSelectionModel().getSelectedItem().getCalorias());
            campoTipoIngredientes.setText(DatosIngredientes.getSelectionModel().getSelectedItem().getTipoIngrediente());
            int indice = 0;
            for (String Alergeno : alergenosObservableList) {
                if (Alergeno.equals(DatosIngredientes.getSelectionModel().getSelectedItem().getAlergenos())) {
                    imgAlergenos.setImage(listaImgAlergenos.get(indice));
                }
                indice++;
            }

        }
    }
    
    
    //Funciones VerIngrediete
    
    
    
    public ObservableList<String> ListaIngredientesSeleccionada(boolean SoloNombres) {
        System.err.println("holaaaa");
        
        ObservableList<String> lista = FXCollections.observableArrayList();

        
        String query = "SELECT i.NombreIngrediente, c.Cantidad, c.UnidadMedida " +
                       "FROM Ingredientes i " +
                       "INNER JOIN Contiene c ON i.Id_Ingrediente = c.Id_Ingrediente " +
                       "WHERE c.Id_Receta = ?";

        try {
            
            if (DatosRecetas.getSelectionModel().getSelectedItem() == null) {
                lista.add("No hay niguna receta seleccionada");
                
            }else{
                PreparedStatement preparedStatement = this.conexion.prepareStatement(query);
                preparedStatement.setInt(1, DatosRecetas.getSelectionModel().getSelectedItem().getId());
                ResultSet resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    String ingrediente = "";
                    
                    if (SoloNombres) {
                        ingrediente += resultSet.getString("NombreIngrediente");
                    }else{
                        ingrediente += resultSet.getString("NombreIngrediente") + " " +
                                  resultSet.getInt("Cantidad") + " " + 
                                  resultSet.getString("UnidadMedida");
                    }
                    lista.add(ingrediente);
                }
            }
            
        } catch (SQLException e) {
            System.out.println("Excepción: " + e.getMessage());
        }

        return lista;
    }
    
    
    //Funciones AñadirIngrediente
    
    
    public Receta RecetaSeleccionada() {
        return DatosRecetas.getSelectionModel().getSelectedItem();
    }
    public Ingrediente IngredienteSeleccionado() {
        return DatosIngredientes.getSelectionModel().getSelectedItem();
    }
    
    
    
    public boolean agregarIngredienteContiene(int idIngrediente,int idReceta, int cantidad, String unidadMedida) {
        if (conexion != null) {
            String query = "INSERT INTO Contiene (Cantidad, UnidadMedida, Id_Receta, Id_Ingrediente) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = conexion.prepareStatement(query)) {
                preparedStatement.setInt(1, cantidad);
                preparedStatement.setString(2, unidadMedida);
                preparedStatement.setInt(3, idReceta);
                preparedStatement.setInt(4, idIngrediente);

                int filasAfectadas = preparedStatement.executeUpdate();
                return filasAfectadas > 0;
            } catch (SQLException e) {
                System.out.println("Error al insertar en la tabla Contiene: " + e.getMessage());
            }
        }
        return false;
    }
    
    public boolean actualizarIngredienteContiene(int idIngrediente, int idReceta, int cantidad, String unidadMedida) {
    if (conexion != null) {
        String query = "UPDATE Contiene SET Cantidad = ?, UnidadMedida = ? WHERE Id_Receta = ? AND Id_Ingrediente = ?";
        try (PreparedStatement preparedStatement = conexion.prepareStatement(query)) {
            
            preparedStatement.setInt(1, cantidad);
            preparedStatement.setString(2, unidadMedida);
            preparedStatement.setInt(3, idReceta);
            preparedStatement.setInt(4, idIngrediente);

            
            int filasAfectadas = preparedStatement.executeUpdate();

          
            return filasAfectadas > 0;
        } catch (SQLException e) {
            System.out.println("Error al actualizar la tabla Contiene: " + e.getMessage());
        }
    }
    return false;
}

    
    
    public boolean borrarIngredienteContiene(int idIngrediente, int idReceta) {
        
        if (conexion != null) {
            String query = "DELETE FROM Contiene WHERE Id_Ingrediente = ? AND Id_Receta = ?";
            try (PreparedStatement preparedStatement = conexion.prepareStatement(query)) {
                preparedStatement.setInt(1, idIngrediente);
                preparedStatement.setInt(2, idReceta);

                int filasAfectadas = preparedStatement.executeUpdate();
                return filasAfectadas > 0;
            } catch (SQLException e) {
                System.out.println("Error al eliminar de la tabla Contiene: " + e.getMessage());
            }
        }
        return false;
    }


    //Funcion Añadir Ingrdientes y Recetas
    
    
    public void insertarReceta(String nombre, int tiempoPreparacion, String pasos, String dificultad, String foto) {
        if (conexion == null) {
            throw new IllegalStateException("La conexión a la base de datos no está inicializada.");
        }

        String query = "INSERT INTO Receta (NombreReceta, TiempoPreparacion, PasosPreparacion, Dificultad, Foto) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = conexion.prepareStatement(query)) {
           
            preparedStatement.setString(1, nombre); 
            preparedStatement.setInt(2, tiempoPreparacion); 
            preparedStatement.setString(3, pasos); 
            preparedStatement.setString(4, dificultad);
            preparedStatement.setString(5, foto); 

           
            int filasInsertadas = preparedStatement.executeUpdate();

            if (filasInsertadas > 0) {
                System.out.println("Receta insertada correctamente.");
            } else {
                System.out.println("No se insertó ninguna receta.");
            }
        } catch (SQLException e) {
            System.out.println("Error al insertar en la tabla Recetas: " + e.getMessage());
            e.printStackTrace();
        }
        mostrarReceta();
        
    }
    
    
    public void insertarIngrediente(int calorias, String alergenos, String tipoIngrediente, String nombreIngrediente) {
        if (conexion == null) {
            throw new IllegalStateException("La conexión a la base de datos no está inicializada.");
        }
        String query = "INSERT INTO Ingredientes (Calorias, Alergenos, TipoIngrediente, NombreIngrediente) VALUES (?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = conexion.prepareStatement(query)) {
            preparedStatement.setInt(1, calorias); 
            preparedStatement.setString(2, alergenos); 
            preparedStatement.setString(3, tipoIngrediente); 
            preparedStatement.setString(4, nombreIngrediente); 
            int filasAfectadas = preparedStatement.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("Ingrediente agregado correctamente.");
            } else {
                System.out.println("No se pudo agregar el ingrediente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al insertar en la tabla Ingredientes: " + e.getMessage());
            e.printStackTrace();
        }
        mostrarIngredientes();
    }

    
    public void modificarIngrediente(int idIngrediente, int calorias, String alergenos, String tipoIngrediente, String nombreIngrediente) {
        if (conexion == null) {
            throw new IllegalStateException("La conexión a la base de datos no está inicializada.");
        }
        String query = "UPDATE Ingredientes SET Calorias = ?, Alergenos = ?, TipoIngrediente = ?, NombreIngrediente = ? WHERE Id_Ingrediente = ?";
        
        try (PreparedStatement preparedStatement = conexion.prepareStatement(query)) {
            preparedStatement.setInt(1, calorias); 
            preparedStatement.setString(2, alergenos); 
            preparedStatement.setString(3, tipoIngrediente); 
            preparedStatement.setString(4, nombreIngrediente); 
            preparedStatement.setInt(5, idIngrediente); 
            
            int filasAfectadas = preparedStatement.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Ingrediente modificado correctamente.");
            } else {
                System.out.println("No se encontró ningún ingrediente con el ID especificado o no se modificó ningún dato.");
            }
        } catch (SQLException e) {
            
            System.out.println("Error al actualizar en la tabla Ingredientes: " + e.getMessage());
            e.printStackTrace();
        }
        actualizarCampos(false);
        mostrarIngredientes();
        
    }
    
    

    public void modificarReceta(int idReceta, String nombreReceta, int tiempoPreparacion, String pasosPreparacion, String dificultad, String foto) {
        if (conexion == null) {
            throw new IllegalStateException("La conexión a la base de datos no está inicializada.");
        }
        System.err.println(""+idReceta);
        String query = "UPDATE Receta SET NombreReceta = ?, TiempoPreparacion = ?, PasosPreparacion = ?, Dificultad = ?, Foto = ? WHERE Id_Receta = ?";
        try (PreparedStatement preparedStatement = conexion.prepareStatement(query)) {
            preparedStatement.setString(1, nombreReceta);
            preparedStatement.setInt(2, tiempoPreparacion);
            preparedStatement.setString(3, pasosPreparacion);
            preparedStatement.setString(4, dificultad);
            preparedStatement.setString(5, foto);
            preparedStatement.setInt(6, idReceta);
            preparedStatement.executeUpdate();

         
        } catch (SQLException e) {
            System.out.println("Error al actualizar en la tabla Receta: " + e.getMessage());
            e.printStackTrace();
        }
        actualizarCampos(true);
        mostrarReceta();
        
    }


      
    
    
    //Convertir a Base 64
    
    public String convetir64(Image imagen){
        
        String base64 = "";

        try {
            Image resizedImage = new Image(imagen.getUrl(), 1280, 720, true, true);
            
            
            BufferedImage bufferedImage = SwingFXUtils.fromFXImage(resizedImage, null);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(bufferedImage, "png", baos);
            
            
            byte[] imageBytes = baos.toByteArray();
            String base64Image = Base64.getEncoder().encodeToString(imageBytes);
            
            base64 = base64Image;
            
        } catch (IOException ex) {
            System.err.println(ex);
        }

        return base64;
       
    }
    
    public Image convertirDesdeBase64(String base64) {
        Image imagen = null;

        try {
            
            byte[] imageBytes = Base64.getDecoder().decode(base64);
            ByteArrayInputStream bais = new ByteArrayInputStream(imageBytes);
            BufferedImage bufferedImage = ImageIO.read(bais);
            imagen = SwingFXUtils.toFXImage(bufferedImage, null);
        } catch (IOException | IllegalArgumentException ex) {
            System.err.println("Error al convertir Base64 a imagen: " + ex.getMessage());
        }

        return imagen;
    }
    
    
    
    
    
    public void applyFadeAnimation(javafx.scene.Node node) {
        FadeTransition fadeTransition = new FadeTransition(Duration.millis(1000), node);
        fadeTransition.setFromValue(0.0);
        fadeTransition.setToValue(1.0);
        fadeTransition.play();
    }
    


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            conexion = this.getConnection();
            if (conexion != null) {
                this.st = conexion.createStatement();
            }
        } catch (IOException | SQLException e) {
           System.err.println(e.toString());
           
            
        }
        if (conexion != null) {
          
           
            
            
            
            Id_Recetas.setCellValueFactory(new PropertyValueFactory<>("id"));
            Nombre_Recetas.setCellValueFactory(new PropertyValueFactory<>("NombreReceta"));
            Pasos.setCellValueFactory(new PropertyValueFactory<>("Pasos"));
            Tiempo.setCellValueFactory(new PropertyValueFactory<>("Tiempo"));
            Dificultad.setCellValueFactory(new PropertyValueFactory<>("Dificultad"));
            Dificultad.setCellValueFactory(new PropertyValueFactory<>("Dificultad"));
            Imagen.setCellValueFactory(new PropertyValueFactory<>("Foto"));

            DatosRecetas.setItems(dameListaRecetas());
            
            
            
          
            
            Id_Ingrediente.setCellValueFactory(new PropertyValueFactory<>("id"));
            NombreIngrediente.setCellValueFactory(new PropertyValueFactory<>("NombreIngrediente"));
            Alergenos.setCellValueFactory(new PropertyValueFactory<>("Alergenos"));
            Calorias.setCellValueFactory(new PropertyValueFactory<>("Calorias"));
            TipoIngrediente.setCellValueFactory(new PropertyValueFactory<>("TipoIngrediente"));

            DatosIngredientes.setItems(dameListaIngredientes());
            
            imagenAñadir.setImage(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/añadir.png")));
            imagenBorrar.setImage(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/eliminar.png")));
            imagenEditar.setImage(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/editar.png")));
            imagenSalir.setImage(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/salida.png")));
            
            Tablas.getSelectionModel().selectedItemProperty().addListener((observable, oldTab, newTab) -> {
                if (newTab != null) {
                    applyFadeAnimation(newTab.getContent());
                }
            });
            
           
            
            imagenAñadirIngredientes.setImage(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/AñadirIngredientes.png")));
            imagenVerIngredientes.setImage(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/verIngredientes.png")));
            imagenAyuda.setImage(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/ayuda.png")));
            imagenBuscar.setImage(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/lupa.png")));
            
            
            Tablas.getStyleClass().add("Tab-background");
            ImagenReceta.getStyleClass().add("rounded-image");   
            panePrincipal.getStyleClass().add("pane-background");
            toolbar.getStyleClass().add("toolbar-background");
            toolbar2.getStyleClass().add("toolbar-background");
            toolbar3.getStyleClass().add("toolbar-background");          
            
        }
    }

}



