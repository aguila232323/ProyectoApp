package VentanaVerIngrediente;
import AppPrincipal.Ejercicio2Builder;
import AppPrincipal.Ejercicio2Main;
import Modelo.Receta;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import javafx.scene.control.ListView;
import javafx.stage.Stage;



public class VerIngredientesBuilder implements Initializable {
    
    

    private Ejercicio2Builder controladorBuilder;
    
    @FXML
    private Button BtnAceptar;

    @FXML
    private ListView<String> listViewIngredientes;

    @FXML
    private Text textoIngredientes;

    @FXML
    void cerrarVentana(ActionEvent event) {
        
        Stage stage = (Stage) BtnAceptar.getScene().getWindow();
        stage.close();

    }
    
    
    public void setControladorEnlace(Ejercicio2Builder ejercicio2Builder) {
        controladorBuilder = ejercicio2Builder;
        System.err.println(controladorBuilder.ListaIngredientesSeleccionada(false).toString()); 
        listViewIngredientes.setItems(controladorBuilder.ListaIngredientesSeleccionada(false));
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
       
        
    }

}



