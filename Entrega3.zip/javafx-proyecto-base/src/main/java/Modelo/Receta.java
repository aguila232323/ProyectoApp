package Modelo;

public class Receta {

    private final int id;
    private final String NombreReceta;
    private final String Pasos;
    private final int Tiempo;
    private final String Dificultad;
    private final String Foto;

    public Receta(int Id, String NombreReceta, String Pasos, int Tiempo, String Dificultad,String Foto){
        this.id = Id;
    	this.NombreReceta=NombreReceta;
        this.Pasos = Pasos;
        this.Tiempo=Tiempo;
        this.Dificultad=Dificultad;
        this.Foto=Foto;
    }

    public int getId() {
    	return id;
    }
    public String getNombreReceta() {
        return NombreReceta;
    }

    public String getPasos() {
        return Pasos;
    }

    public int getTiempo() {
        return Tiempo;
    }

    public String getDificultad() {
        return Dificultad;
    }
    public String getFoto() {
        return Foto;
    }
}
