package VentanaAnadirRegistro;
import AppPrincipal.Ejercicio2Builder;
import Modelo.Ingrediente;
import VentanaVerIngrediente.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import org.controlsfx.validation.Severity;
import org.controlsfx.validation.ValidationMessage;
import org.controlsfx.validation.ValidationResult;
import org.controlsfx.validation.ValidationSupport;
import org.controlsfx.validation.Validator;
import org.controlsfx.validation.decoration.GraphicValidationDecoration;


public class anadirDatosIngredientesBuilder implements Initializable {
    
    public  boolean editar = false;
    
    private Ejercicio2Builder controladorBuilder;

    List<ValidationSupport> validadores;
    
    
    
    
    @FXML
    private Label LabelTipoIngrediente;
    
    @FXML
    private Label labelAlergenos;

    @FXML
    private Label labelCalorias;

    @FXML
    private Label labelNombre;
    
    @FXML
    private Label IconoTipoIngrediente;
    
    @FXML
    private Label iconoAlergenos;

    @FXML
    private Label iconoCalorias;

    @FXML
    private Label iconoNombre;


    @FXML
    private Button aceptar;
    
    
    @FXML
    private ComboBox<String> comboAlergenos;

    @FXML
    private ComboBox<String> comboTipoIngrediente;


    @FXML
    private TextField campoCalorias;

    @FXML
    private TextField campoNombreIngrediente;

    @FXML
    private Button cancelar;

    @FXML
    private Pane ventana;
    
    

    @FXML
    void aceptar(ActionEvent event) {
        
        
        System.out.println("Comprobación de DATOS");
        System.out.println("=====================");
        for (ValidationSupport validationSupport : validadores) {
            ValidationResult resultados = validationSupport.getValidationResult();
            System.out.println("Validador: " + validationSupport.getRegisteredControls());
            System.out.println("Errores: " + resultados.getErrors());
            System.out.println("Infos: " + resultados.getInfos());
            System.out.println("Mensajes: " + resultados.getMessages());
            System.out.println("Warnings: " + resultados.getWarnings());
        }

        boolean todoOK = true;
        for (ValidationSupport validationSupport : validadores) {
            todoOK = (todoOK && validationSupport.getValidationResult().getErrors().isEmpty());
        }

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        if (todoOK) {
            alert.setContentText(("Todo Correcto"));
            
            if (editar) {
                controladorBuilder.modificarIngrediente(controladorBuilder.IngredienteSeleccionado().getId(), Integer.parseInt(campoCalorias.getText()) , comboAlergenos.getValue(), comboTipoIngrediente.getValue(), campoNombreIngrediente.getText());
            }else{
                
                int calorias = Integer.parseInt(campoCalorias.getText());
                
                controladorBuilder.insertarIngrediente( calorias, comboAlergenos.getValue(), comboTipoIngrediente.getValue(), campoNombreIngrediente.getText());
            }
             
             
             Stage stage = (Stage) aceptar.getScene().getWindow();
            stage.close();
        } else {
            alert.setContentText(("El formulario tiene Errores!!!"));
        }
        alert.showAndWait();
        
        
        
       

    }

    @FXML
    void cancelar(ActionEvent event) {
        Stage stage = (Stage) cancelar.getScene().getWindow();
        stage.close();
    }
    
    public void editar() {
        campoNombreIngrediente.setText(controladorBuilder.IngredienteSeleccionado().getNombreIngrediente());
        campoCalorias.setText(""+controladorBuilder.IngredienteSeleccionado().getCalorias());
        comboAlergenos.setValue(controladorBuilder.IngredienteSeleccionado().getAlergenos());
        comboTipoIngrediente.setValue(controladorBuilder.IngredienteSeleccionado().getTipoIngrediente());
        
        
    }
    
    
    
    public void setControladorEnlace(Ejercicio2Builder ejercicio2Builder) {
        controladorBuilder = ejercicio2Builder;
        comboAlergenos.getItems().addAll(controladorBuilder.alergenosObservableList);
        if (editar) {
            editar();
        }
        
    }




    @Override
    public void initialize(URL url, ResourceBundle rb) {
       validadores = new ArrayList<>();
       
       
        
      
        
        ObservableList<String> tiposObservableList = FXCollections.observableArrayList(
                "Harinas y cereales",
                "Legumbres",
                "Lacteos",
                "Huevos",
                "Pescado",
                "Carne",
                "Verdura",
                "Fruta",
                "Especias",
                "Conservas",
                "Reposteria",
                "Alcohol"
        );
        
        
        
        comboTipoIngrediente.getItems().addAll(tiposObservableList);
        
        
        comboTipoIngrediente.setValue("Harinas y cereales");
        comboAlergenos.setValue("Ninguno");
       
        labelNombre.setTooltip(new Tooltip("Nombre del Ingrediente"));
        labelCalorias.setTooltip(new Tooltip("Número (máximo 3 dígitos)"));
        labelAlergenos.setTooltip(new Tooltip("Alergenos del Ingrediente"));
        LabelTipoIngrediente.setTooltip(new Tooltip("Selecciona un tipo de Ingrediente"));
        
        
        ImageView iconoOk = new ImageView(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/ok_icon.png")));
        ImageView iconoErr = new ImageView(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/error_icon.png")));
        iconoOk.setFitHeight(16);
        iconoOk.setFitWidth(16);
        iconoErr.setFitHeight(16);
        iconoErr.setFitWidth(16);
        
       
        
        ValidationSupport vSnombre = new ValidationSupport();
        
        
        vSnombre.registerValidator(campoNombreIngrediente, false, (Control c, String texto) -> {
            if (texto.length() == 0) {
                return ValidationResult.fromWarning(c, "Val 3: El nombre no debe estar vacío");
            } else if (texto.length() < 5 || texto.length() > 100) {
                return ValidationResult.fromError(c, "Val 3: El nombre debe tener entre 5 y 100 caracteres");
            } else {
                return ValidationResult.fromInfo(c, "Val 3: OK");
            }
        });
        
        
        
        ValidationSupport vSCalorias = new ValidationSupport();
        Validator<String> rangoValidator = Validator.createPredicateValidator(valor -> {
            if (valor == null || valor.isEmpty()) {
                return false;
            }
            try {
                int number = Integer.parseInt(valor);
                return number >= 0 && number <= 9999;
            } catch (NumberFormatException e) {
                return false; 
            }
        }, "Valor debe estar entre 0 y 9999 o NO es un número");
        
        vSCalorias.registerValidator(campoCalorias, false, rangoValidator);
        
        
        ValidationSupport vSTipoIngrediente = new ValidationSupport();
        Validator<String> validadorCombo = Validator.createPredicateValidator(
                texto -> !("".equals(texto)),
                "Hay que elegir Tipo ingrediente!", //
                Severity.ERROR 
        );
        vSTipoIngrediente.registerValidator(comboTipoIngrediente, false,validadorCombo);
        
        ValidationSupport vSalergenos = new ValidationSupport();
        Validator<String> validadorCombo2 = Validator.createPredicateValidator(
                texto -> !("".equals(texto)),
                "Hay que elegir Alergeno!", //
                Severity.ERROR 
        );
        vSalergenos.registerValidator(comboAlergenos,false, validadorCombo2);
        
        
        GraphicValidationDecoration decorador = new GraphicValidationDecoration() {
            @Override
            public void applyValidationDecoration(ValidationMessage message) {
                super.applyValidationDecoration(message);
                System.out.println("Mensaje:" + message);
                
                if (message.getSeverity() == Severity.ERROR || message.getSeverity() == Severity.WARNING) {
                    iconoNombre.setGraphic(iconoErr);//ICONO ERROR
                } else if (message.getSeverity() == Severity.INFO) {
                   iconoNombre.setGraphic(iconoOk);//ICONO OK
                }
            }
        };
        
        validadores = new ArrayList<>();
        validadores.addAll(Arrays.asList(vSnombre, vSCalorias, vSTipoIngrediente, vSalergenos));
        
        
        
        
        Platform.runLater(() -> {
            for (ValidationSupport validationSupport : validadores) {
                validationSupport.initInitialDecoration();
            }
            vSnombre.setValidationDecorator(decorador);
        });
    }

}



