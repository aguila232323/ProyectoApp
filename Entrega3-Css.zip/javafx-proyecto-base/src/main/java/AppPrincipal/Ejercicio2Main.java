package AppPrincipal;

import com.pixelduke.transit.Style;
import com.pixelduke.transit.TransitTheme;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;


public class Ejercicio2Main extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primeraEscena) throws Exception { 
        
        
        FXMLLoader loader = new FXMLLoader(getClass().getResource("App2.fxml"));
         Parent root = loader.load();
         Ejercicio2Builder controller = loader.getController();
        
        Scene scene = new Scene(root);
        
        
         scene.setOnKeyPressed(e -> {
            if (e.isControlDown()) {
                switch (e.getCode()) {
                    case E:
                        controller.editarCampo(new ActionEvent());
                        break;
                    case A:
                        controller.añadirCampos(new ActionEvent());
                        break;
                    case X:
                        controller.salir(new ActionEvent());
                        break;
                    case DELETE:
                        controller.borrarCampo(new ActionEvent());
                        break;
                }
            }
        });
        primeraEscena.getIcons().add(new Image(getClass().getClassLoader().getResourceAsStream("Imagenes/logoApp.png")));
        
        scene.getStylesheets().add(getClass().getResource("estilos.css").toString());
        
        primeraEscena.setScene(scene);
        primeraEscena.setTitle("RecipeVault");
        primeraEscena.show();
        
        
    }
}

